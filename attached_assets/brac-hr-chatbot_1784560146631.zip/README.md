# BRAC HR Assistant

An org-internal HR chatbot for BRAC. It answers employee HR questions grounded
in an **existing Vertex AI Search (Discovery Engine) data store** of HR policy
documents, cites its sources, and is restricted to **@brac.net Google Workspace
accounts**. No per-seat licensing — the app calls the Discovery Engine Answer
API directly (pay-as-you-go) and deploys as a **single Cloud Run service**.

- **Framework:** Next.js 15 (App Router, TypeScript) — one service serves both UI and API.
- **Auth:** Google Identity Services + server-side ID-token verification (`hd == brac.net`).
- **Answers:** Discovery Engine v1 `servingConfigs.answer` (multi-turn sessions, citations, streamed to the client over SSE).
- **State:** Firestore (conversations, feedback, rate-limit counters, answer cache) — the service itself is stateless.

---

## 1. Local development

### Option A — mock mode (zero GCP setup)

Runs the full UI with canned answers and an in-memory store. **Hard-disabled in
production** (`NODE_ENV=production` overrides it).

```bash
pnpm install
cp .env.example .env.local
# edit .env.local: set MOCK_MODE=true
pnpm dev
# open http://localhost:3000  →  "Continue (mock dev user)"
```

### Option B — against the real data store

```bash
cp .env.example .env.local     # fill in Section 0 values (see table below)
gcloud auth application-default login   # provides ADC for Discovery Engine + Firestore
pnpm dev
```

### Configuration (env vars — never hardcode)

| Env var | Example | Notes |
|---|---|---|
| `GCP_PROJECT_ID` | `brac-hr-chatbot` | Project hosting the data store |
| `GCP_LOCATION` | `global` | Data store location |
| `ENGINE_ID` | `brac-hr_1234567890` | Vertex AI Search app id (preferred) |
| `DATA_STORE_ID` | *(empty)* | Used only if `ENGINE_ID` is empty |
| `GOOGLE_OAUTH_CLIENT_ID` | `xxx.apps.googleusercontent.com` | OAuth 2.0 **Web** client |
| `ALLOWED_HOSTED_DOMAIN` | `brac.net` | Only Workspace domain allowed |
| `SESSION_SECRET` | *(generate)* | `openssl rand -base64 48` |
| `RATE_LIMIT_PER_HOUR` | `30` | Questions per user per hour |
| `ANSWER_CACHE_TTL_SECONDS` | `3600` | Identical-question cache TTL |
| `SESSION_HOURS` | `8` | Session cookie lifetime |

### Tests

```bash
pnpm test        # ID-token verification (incl. wrong hd), answer-API proxy, rate limiting, cache
pnpm typecheck
```

---

## 2. One-time GCP setup

### 2.1 Enable APIs

```bash
gcloud config set project "$GCP_PROJECT_ID"
gcloud services enable \
  discoveryengine.googleapis.com \
  firestore.googleapis.com \
  run.googleapis.com \
  artifactregistry.googleapis.com \
  cloudbuild.googleapis.com
```

### 2.2 Firestore (native mode)

```bash
gcloud firestore databases create --location=nam5   # or your preferred region
```

No schema to create — collections are created on first write. Recommended TTL
policies (Firestore console → TTL) to keep costs flat:

- `answerCache` → field `expiresAt` (millis). *(App also checks expiry on read.)*
- `rateLimits` → add a TTL field if you want old counters garbage-collected.

### 2.3 OAuth 2.0 Web client

1. **APIs & Services → Credentials → Create credentials → OAuth client ID → Web application.**
2. **Authorized JavaScript origins:**
   - `http://localhost:3000` (dev)
   - `https://<your-cloud-run-url>` (added after first deploy — see §3.4)
3. **Authorized redirect URIs:** none needed (we use the GIS token flow, not the redirect flow).
4. Copy the **Client ID** into `GOOGLE_OAUTH_CLIENT_ID`.
5. On the **OAuth consent screen**, set User type = **Internal** so only brac.net users can even reach it (defence in depth on top of the server-side `hd` check).

---

## 3. Deploy to Cloud Run

### 3.1 Runtime service account (least privilege)

```bash
gcloud iam service-accounts create brac-hr-runtime \
  --display-name="BRAC HR Chatbot runtime"

RUNTIME_SA="brac-hr-runtime@${GCP_PROJECT_ID}.iam.gserviceaccount.com"

# Discovery Engine: query only
gcloud projects add-iam-policy-binding "$GCP_PROJECT_ID" \
  --member="serviceAccount:${RUNTIME_SA}" \
  --role="roles/discoveryengine.user"

# Firestore: read/write app data
gcloud projects add-iam-policy-binding "$GCP_PROJECT_ID" \
  --member="serviceAccount:${RUNTIME_SA}" \
  --role="roles/datastore.user"
```

### 3.2 Store secrets in Secret Manager

```bash
gcloud services enable secretmanager.googleapis.com
printf '%s' "$(openssl rand -base64 48)" | \
  gcloud secrets create brac-hr-session-secret --data-file=-
gcloud secrets add-iam-policy-binding brac-hr-session-secret \
  --member="serviceAccount:${RUNTIME_SA}" \
  --role="roles/secretmanager.secretAccessor"
```

### 3.3 Deploy (source-based build — no local Docker needed)

```bash
gcloud run deploy brac-hr-chatbot \
  --source . \
  --region=asia-south1 \
  --service-account="$RUNTIME_SA" \
  --allow-unauthenticated \
  --min-instances=1 \
  --max-instances=20 \
  --concurrency=80 \
  --cpu=1 --memory=512Mi \
  --set-env-vars="GCP_PROJECT_ID=${GCP_PROJECT_ID},GCP_LOCATION=global,ENGINE_ID=${ENGINE_ID},GOOGLE_OAUTH_CLIENT_ID=${GOOGLE_OAUTH_CLIENT_ID},ALLOWED_HOSTED_DOMAIN=brac.net,RATE_LIMIT_PER_HOUR=30,ANSWER_CACHE_TTL_SECONDS=3600,SESSION_HOURS=8" \
  --set-secrets="SESSION_SECRET=brac-hr-session-secret:latest"
```

> `--allow-unauthenticated` lets the browser reach the service; **the app's own
> Google sign-in + `hd` check is the real gate**. Every route except `/healthz`
> and the sign-in page verifies the session server-side.

### 3.4 Wire up the OAuth origin

Copy the service URL from the deploy output and add it to the OAuth client's
**Authorized JavaScript origins** (§2.3). Sign-in fails with a GSI error until
this is done.

### 3.5 Verify

```bash
curl -s https://<your-cloud-run-url>/healthz     # {"status":"ok",...}
```

Open the URL, sign in with a brac.net account, ask a question, confirm the
answer streams with citations. A gmail.com account should be cleanly rejected.

---

## 4. Security notes

- Browser never holds service credentials or calls Google Cloud APIs directly.
- ID token verified server-side every sign-in (signature, `aud`, `iss`, `exp`, **`hd`**); a short-lived signed HttpOnly session cookie avoids re-verifying per keystroke.
- CSRF: SameSite=Lax cookie + same-origin check on state-changing routes. Strict CSP, `nosniff`, `X-Frame-Options: DENY`.
- Least-privilege runtime SA (`discoveryengine.user` + `datastore.user` only).
- **Log retention note:** we log a salted **hash** of the user id, latency, error class, and citation counts — never the email in app logs (only in stored feedback, by design) and never question contents at INFO. If you need question-level debugging, raise the log level deliberately and document the retention window.

---

## 5. Project layout

```
src/
  app/
    api/
      auth/session/route.ts    # sign-in / whoami / sign-out
      chat/route.ts            # SSE streaming answer endpoint
      conversations/…          # list/create/get/rename/delete
      feedback/route.ts        # 👍/👎 → Firestore
    healthz/route.ts           # liveness
    page.tsx / HomeClient.tsx  # auth gate → chat
  components/                  # Sidebar, ChatApp, Message, Composer, CitationChips, LoginScreen…
  lib/
    auth.ts       # ID-token verify + session JWT + hd gate
    discovery.ts  # Discovery Engine Answer API client (+ mock answers)
    db.ts         # Firestore + in-memory (mock) data layer
    ratelimit.ts  # per-user hourly counters
    cache.ts      # question normalization + hashing
    config.ts     # all env-var config
    logger.ts     # structured JSON logs
tests/            # auth, discovery, ratelimit, cache
```

See [SCALING.md](./SCALING.md) for what to change at 100 / 1,000 / 10,000 daily users.
