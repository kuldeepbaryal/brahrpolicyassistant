/**
 * All runtime configuration. Nothing here is ever hardcoded elsewhere —
 * import from this module only.
 */

function req(name: string): string {
  const v = process.env[name];
  if (!v && !isMockMode()) {
    throw new Error(`Missing required env var: ${name}`);
  }
  return v ?? "";
}

export function isMockMode(): boolean {
  // Hard-disabled in production: setting MOCK_MODE on Cloud Run does nothing.
  return process.env.MOCK_MODE === "true" && process.env.NODE_ENV !== "production";
}

export const config = {
  get projectId() {
    return req("GCP_PROJECT_ID");
  },
  get location() {
    return process.env.GCP_LOCATION || "global";
  },
  get engineId() {
    return process.env.ENGINE_ID || "";
  },
  get dataStoreId() {
    return process.env.DATA_STORE_ID || "";
  },
  get oauthClientId() {
    return req("GOOGLE_OAUTH_CLIENT_ID");
  },
  get allowedHostedDomain() {
    return process.env.ALLOWED_HOSTED_DOMAIN || "brac.net";
  },
  get sessionSecret() {
    const s = req("SESSION_SECRET");
    if (!s && isMockMode()) return "mock-mode-dev-secret-do-not-use-in-prod";
    return s;
  },
  get sessionHours() {
    return Number(process.env.SESSION_HOURS || 8);
  },
  get rateLimitPerHour() {
    return Number(process.env.RATE_LIMIT_PER_HOUR || 30);
  },
  get answerCacheTtlSeconds() {
    return Number(process.env.ANSWER_CACHE_TTL_SECONDS || 3600);
  },
};
