/**
 * Data layer. Everything shared between Cloud Run instances lives here —
 * the service itself holds no state, so it scales horizontally.
 *
 * Firestore layout:
 *   users/{sub}/conversations/{convId}            → Conversation
 *   users/{sub}/conversations/{convId}/messages/* → ChatMessage
 *   feedback/{autoId}                             → feedback events
 *   answerCache/{questionHash}                    → cached AnswerResult
 *   rateLimits/{sub_YYYYMMDDHH}                   → { count }
 *
 * In mock mode an in-memory store is used instead so the app runs with zero
 * GCP credentials (dev only — hard-disabled in production).
 */
import { Firestore } from "@google-cloud/firestore";
import { isMockMode, config } from "./config";
import type { AnswerResult, ChatMessage, Conversation } from "./types";

export interface FeedbackEvent {
  userEmail: string;
  conversationId: string;
  messageId: string;
  rating: "up" | "down";
  question: string;
  answer: string;
  citations: { title: string; uri: string }[];
  createdAt: number;
}

export interface Db {
  listConversations(sub: string): Promise<Conversation[]>;
  createConversation(sub: string, title: string): Promise<Conversation>;
  getConversation(sub: string, id: string): Promise<Conversation | null>;
  renameConversation(sub: string, id: string, title: string): Promise<void>;
  deleteConversation(sub: string, id: string): Promise<void>;
  setEngineSession(sub: string, id: string, engineSessionName: string): Promise<void>;
  touchConversation(sub: string, id: string): Promise<void>;

  listMessages(sub: string, convId: string): Promise<ChatMessage[]>;
  addMessage(sub: string, convId: string, msg: ChatMessage): Promise<void>;
  setMessageFeedback(sub: string, convId: string, messageId: string, rating: "up" | "down"): Promise<void>;

  saveFeedback(event: FeedbackEvent): Promise<void>;

  getCachedAnswer(questionHash: string): Promise<AnswerResult | null>;
  setCachedAnswer(questionHash: string, answer: AnswerResult): Promise<void>;

  /** Atomically increment this user's counter for the current hour window; returns new count. */
  incrementRateCounter(sub: string, windowKey: string): Promise<number>;
}

/* ────────────────────────── Firestore implementation ─────────────────── */

function newId(): string {
  return crypto.randomUUID().replace(/-/g, "").slice(0, 20);
}

class FirestoreDb implements Db {
  private fs: Firestore;

  constructor() {
    this.fs = new Firestore({ projectId: config.projectId, ignoreUndefinedProperties: true });
  }

  private convs(sub: string) {
    return this.fs.collection("users").doc(sub).collection("conversations");
  }

  async listConversations(sub: string): Promise<Conversation[]> {
    const snap = await this.convs(sub).orderBy("updatedAt", "desc").limit(100).get();
    return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Conversation, "id">) }));
  }

  async createConversation(sub: string, title: string): Promise<Conversation> {
    const id = newId();
    const now = Date.now();
    const conv: Omit<Conversation, "id"> = { title, createdAt: now, updatedAt: now, engineSessionName: null };
    await this.convs(sub).doc(id).set(conv);
    return { id, ...conv };
  }

  async getConversation(sub: string, id: string): Promise<Conversation | null> {
    const doc = await this.convs(sub).doc(id).get();
    if (!doc.exists) return null;
    return { id: doc.id, ...(doc.data() as Omit<Conversation, "id">) };
  }

  async renameConversation(sub: string, id: string, title: string): Promise<void> {
    await this.convs(sub).doc(id).update({ title, updatedAt: Date.now() });
  }

  async deleteConversation(sub: string, id: string): Promise<void> {
    const ref = this.convs(sub).doc(id);
    await this.fs.recursiveDelete(ref);
  }

  async setEngineSession(sub: string, id: string, engineSessionName: string): Promise<void> {
    await this.convs(sub).doc(id).update({ engineSessionName });
  }

  async touchConversation(sub: string, id: string): Promise<void> {
    await this.convs(sub).doc(id).update({ updatedAt: Date.now() });
  }

  async listMessages(sub: string, convId: string): Promise<ChatMessage[]> {
    const snap = await this.convs(sub).doc(convId).collection("messages").orderBy("createdAt", "asc").limit(500).get();
    return snap.docs.map((d) => d.data() as ChatMessage);
  }

  async addMessage(sub: string, convId: string, msg: ChatMessage): Promise<void> {
    await this.convs(sub).doc(convId).collection("messages").doc(msg.id).set(msg);
  }

  async setMessageFeedback(sub: string, convId: string, messageId: string, rating: "up" | "down"): Promise<void> {
    await this.convs(sub).doc(convId).collection("messages").doc(messageId).update({ feedback: rating });
  }

  async saveFeedback(event: FeedbackEvent): Promise<void> {
    await this.fs.collection("feedback").add(event);
  }

  async getCachedAnswer(questionHash: string): Promise<AnswerResult | null> {
    const doc = await this.fs.collection("answerCache").doc(questionHash).get();
    if (!doc.exists) return null;
    const data = doc.data() as { answer: AnswerResult; expiresAt: number };
    if (data.expiresAt < Date.now()) return null;
    return data.answer;
  }

  async setCachedAnswer(questionHash: string, answer: AnswerResult): Promise<void> {
    await this.fs.collection("answerCache").doc(questionHash).set({
      answer,
      expiresAt: Date.now() + config.answerCacheTtlSeconds * 1000,
    });
  }

  async incrementRateCounter(sub: string, windowKey: string): Promise<number> {
    const ref = this.fs.collection("rateLimits").doc(windowKey);
    return this.fs.runTransaction(async (tx) => {
      const doc = await tx.get(ref);
      const count = ((doc.data()?.count as number) ?? 0) + 1;
      tx.set(ref, { count, sub, updatedAt: Date.now() });
      return count;
    });
  }
}

/* ─────────────────────── In-memory implementation (mock) ─────────────── */

export class MemoryDb implements Db {
  private conversations = new Map<string, Map<string, Conversation>>();
  private messages = new Map<string, ChatMessage[]>(); // key: sub/convId
  private feedback: FeedbackEvent[] = [];
  private cache = new Map<string, { answer: AnswerResult; expiresAt: number }>();
  private counters = new Map<string, number>();

  private userConvs(sub: string) {
    if (!this.conversations.has(sub)) this.conversations.set(sub, new Map());
    return this.conversations.get(sub)!;
  }

  async listConversations(sub: string) {
    return [...this.userConvs(sub).values()].sort((a, b) => b.updatedAt - a.updatedAt);
  }

  async createConversation(sub: string, title: string) {
    const now = Date.now();
    const conv: Conversation = { id: newId(), title, createdAt: now, updatedAt: now, engineSessionName: null };
    this.userConvs(sub).set(conv.id, conv);
    return conv;
  }

  async getConversation(sub: string, id: string) {
    return this.userConvs(sub).get(id) ?? null;
  }

  async renameConversation(sub: string, id: string, title: string) {
    const c = this.userConvs(sub).get(id);
    if (c) Object.assign(c, { title, updatedAt: Date.now() });
  }

  async deleteConversation(sub: string, id: string) {
    this.userConvs(sub).delete(id);
    this.messages.delete(`${sub}/${id}`);
  }

  async setEngineSession(sub: string, id: string, engineSessionName: string) {
    const c = this.userConvs(sub).get(id);
    if (c) c.engineSessionName = engineSessionName;
  }

  async touchConversation(sub: string, id: string) {
    const c = this.userConvs(sub).get(id);
    if (c) c.updatedAt = Date.now();
  }

  async listMessages(sub: string, convId: string) {
    return this.messages.get(`${sub}/${convId}`) ?? [];
  }

  async addMessage(sub: string, convId: string, msg: ChatMessage) {
    const key = `${sub}/${convId}`;
    if (!this.messages.has(key)) this.messages.set(key, []);
    this.messages.get(key)!.push(msg);
  }

  async setMessageFeedback(sub: string, convId: string, messageId: string, rating: "up" | "down") {
    const msg = (this.messages.get(`${sub}/${convId}`) ?? []).find((m) => m.id === messageId);
    if (msg) msg.feedback = rating;
  }

  async saveFeedback(event: FeedbackEvent) {
    this.feedback.push(event);
  }

  async getCachedAnswer(questionHash: string) {
    const hit = this.cache.get(questionHash);
    if (!hit || hit.expiresAt < Date.now()) return null;
    return hit.answer;
  }

  async setCachedAnswer(questionHash: string, answer: AnswerResult) {
    this.cache.set(questionHash, { answer, expiresAt: Date.now() + config.answerCacheTtlSeconds * 1000 });
  }

  async incrementRateCounter(_sub: string, windowKey: string) {
    const next = (this.counters.get(windowKey) ?? 0) + 1;
    this.counters.set(windowKey, next);
    return next;
  }
}

/* ──────────────────────────────── factory ────────────────────────────── */

// Stash on globalThis so the singleton survives HMR and per-route module
// duplication in dev — otherwise the in-memory (mock) store would differ
// between API routes and conversations created in one route would be invisible
// to another.
const globalForDb = globalThis as unknown as { __bracHrDb?: Db };

export function getDb(): Db {
  if (!globalForDb.__bracHrDb) {
    globalForDb.__bracHrDb = isMockMode() ? new MemoryDb() : new FirestoreDb();
  }
  return globalForDb.__bracHrDb;
}
