/**
 * Discovery Engine v1 client (Vertex AI Search "Answer" API), called via REST
 * with Application Default Credentials — on Cloud Run this is the runtime
 * service account; the browser never touches these APIs.
 *
 * Multi-turn: we create a Discovery Engine *session* per conversation and
 * pass it on every answerQuery so follow-ups keep context.
 */
import { GoogleAuth } from "google-auth-library";
import { config, isMockMode } from "./config";
import { log } from "./logger";
import type { AnswerResult, Citation } from "./types";

const API_BASE = "https://discoveryengine.googleapis.com/v1";

/** Guardrail preamble: answer only from the indexed HR documents. */
const ANSWER_PREAMBLE =
  "You are BRAC's internal HR policy assistant. Answer ONLY using the indexed BRAC HR policy documents. " +
  "If the documents do not contain the answer, say you could not find it in BRAC's HR policies and suggest contacting hr@brac.net. " +
  "Never speculate, never invent policy details, and always ground every statement in the provided documents. " +
  "Format answers with Markdown (short paragraphs, bullet lists for steps or entitlements).";

const auth = new GoogleAuth({ scopes: ["https://www.googleapis.com/auth/cloud-platform"] });

/** Root resource for the serving config / sessions, engine-first. */
function servingParent(): string {
  const p = `projects/${config.projectId}/locations/${config.location}`;
  if (config.engineId) return `${p}/collections/default_collection/engines/${config.engineId}`;
  if (config.dataStoreId) return `${p}/collections/default_collection/dataStores/${config.dataStoreId}`;
  throw new Error("Set ENGINE_ID or DATA_STORE_ID");
}

async function authedFetch(url: string, init: RequestInit): Promise<Response> {
  const token = await auth.getAccessToken();
  return fetch(url, {
    ...init,
    headers: {
      ...(init.headers as Record<string, string>),
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
  });
}

export class QuotaError extends Error {}
export class DiscoveryError extends Error {}

/** Create a Discovery Engine session for a new conversation. */
export async function createEngineSession(userPseudoId: string): Promise<string | null> {
  if (isMockMode()) return `mock-session/${userPseudoId}/${Date.now()}`;
  const res = await authedFetch(`${API_BASE}/${servingParent()}/sessions`, {
    method: "POST",
    body: JSON.stringify({ userPseudoId }),
  });
  if (!res.ok) {
    log.warn("session create failed; continuing sessionless", { status: res.status });
    return null;
  }
  const data = (await res.json()) as { name?: string };
  return data.name ?? null;
}

interface RawAnswer {
  answer?: {
    answerText?: string;
    state?: string;
    answerSkippedReasons?: string[];
    citations?: {
      sources?: { referenceId?: string }[];
    }[];
    references?: {
      chunkInfo?: {
        content?: string;
        documentMetadata?: { title?: string; uri?: string; document?: string };
      };
      unstructuredDocumentInfo?: {
        title?: string;
        uri?: string;
        document?: string;
        chunkContents?: { content?: string }[];
      };
    }[];
    relatedQuestions?: string[];
  };
  session?: { name?: string };
}

function extractCitations(raw: RawAnswer): Citation[] {
  const refs = raw.answer?.references ?? [];
  const seen = new Set<string>();
  const out: Citation[] = [];
  for (const ref of refs) {
    const title =
      ref.chunkInfo?.documentMetadata?.title ?? ref.unstructuredDocumentInfo?.title ?? "HR policy document";
    const uri = ref.chunkInfo?.documentMetadata?.uri ?? ref.unstructuredDocumentInfo?.uri ?? "";
    const snippet = (
      ref.chunkInfo?.content ??
      ref.unstructuredDocumentInfo?.chunkContents?.[0]?.content ??
      ""
    ).slice(0, 400);
    const key = `${title}|${uri}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ title, uri, snippet });
  }
  return out.slice(0, 8);
}

async function withBackoff<T>(fn: () => Promise<T>, tries = 3): Promise<T> {
  let lastErr: unknown;
  for (let i = 0; i < tries; i++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      if (!(err instanceof QuotaError) || i === tries - 1) throw err;
      const delayMs = 500 * 2 ** i + Math.random() * 250;
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }
  throw lastErr;
}

/**
 * Ask the Answer API a question, optionally within an existing session.
 */
export async function answerQuery(
  question: string,
  opts: { sessionName?: string | null; userPseudoId: string }
): Promise<AnswerResult> {
  if (isMockMode()) return mockAnswer(question, opts.sessionName ?? null);

  return withBackoff(async () => {
    const started = Date.now();
    const res = await authedFetch(`${API_BASE}/${servingParent()}/servingConfigs/default_serving_config:answer`, {
      method: "POST",
      body: JSON.stringify({
        query: { text: question },
        ...(opts.sessionName ? { session: opts.sessionName } : {}),
        userPseudoId: opts.userPseudoId,
        answerGenerationSpec: {
          includeCitations: true,
          ignoreAdversarialQuery: true,
          ignoreNonAnswerSeekingQuery: false,
          promptSpec: { preamble: ANSWER_PREAMBLE },
        },
        relatedQuestionsSpec: { enable: true },
      }),
    });

    if (res.status === 429) throw new QuotaError("Discovery Engine quota exceeded");
    if (!res.ok) {
      const body = await res.text();
      log.error("answerQuery failed", { status: res.status, body: body.slice(0, 500) });
      throw new DiscoveryError(`Answer API error (${res.status})`);
    }

    const raw = (await res.json()) as RawAnswer;
    const answerText = raw.answer?.answerText ?? "";
    const skipped = (raw.answer?.answerSkippedReasons?.length ?? 0) > 0;
    const noResults = skipped || answerText.trim().length === 0;

    log.info("answerQuery ok", { latencyMs: Date.now() - started, noResults });

    return {
      answerText,
      citations: extractCitations(raw),
      relatedQuestions: raw.answer?.relatedQuestions ?? [],
      sessionName: raw.session?.name ?? opts.sessionName ?? null,
      noResults,
    };
  });
}

/* ─────────────────────────── mock answers (dev) ──────────────────────── */

const MOCK_ANSWERS: Record<string, string> = {
  leave:
    "### Annual leave at BRAC\n\nRegular full-time staff are entitled to **20 working days of annual leave** per calendar year, accrued monthly.\n\n- Leave must be requested through the HRIS at least **7 days in advance**.\n- Up to **10 unused days** may be carried into the next year.\n- Carried-over days must be used by **31 March**.\n\nDuring probation, leave accrues but may only be taken with your supervisor's written approval.",
  maternity:
    "### Maternity leave policy\n\nBRAC provides **26 weeks (182 days) of fully paid maternity leave** for all female staff, in line with national law and BRAC's own family-friendly workplace policy.\n\n1. Notify HR in writing at least **8 weeks** before the expected delivery date with a medical certificate.\n2. Leave may begin up to **8 weeks** before the due date.\n3. On return, nursing mothers are entitled to **two 30-minute nursing breaks** per day for 6 months.\n\nAdoptive mothers are entitled to **12 weeks** of paid leave from the date of placement.",
  probation:
    "### Probation period\n\nNew regular staff serve a **6-month probation period**.\n\n- A mid-point check-in happens at 3 months, and a confirmation review before the end of month 6.\n- Probation may be extended **once, by up to 3 months**, with written justification.\n- During probation either party may end employment with **2 weeks' notice**.",
};

function mockAnswer(question: string, sessionName: string | null): AnswerResult {
  const q = question.toLowerCase();
  // Match more specific topics before the generic "leave" fallback.
  const key = ["maternity", "probation", "leave"].find((k) => q.includes(k));
  const answerText =
    (key && MOCK_ANSWERS[key]) ??
    `Here is what BRAC's HR policies say about that:\n\n- This is a **mock answer** (MOCK_MODE is on — no GCP credentials in use).\n- In production this response is generated by Vertex AI Search over BRAC's indexed HR documents.\n- Your question was: _"${question}"_`;
  return {
    answerText,
    citations: [
      {
        title: "BRAC HR Policy Manual 2025 — Chapter 4: Leave & Benefits",
        uri: "https://drive.google.com/mock-hr-policy-manual",
        snippet: "Section 4.2 sets out leave entitlements for regular full-time staff, including annual, sick, maternity, paternity and compassionate leave…",
      },
      {
        title: "BRAC Employee Handbook — Working at BRAC",
        uri: "https://drive.google.com/mock-employee-handbook",
        snippet: "This handbook summarises the terms and conditions of employment applicable to all BRAC staff worldwide…",
      },
    ],
    relatedQuestions: [
      "How do I apply for annual leave?",
      "What is the sick leave policy?",
      "Can unused leave be encashed?",
    ],
    sessionName: sessionName ?? `mock-session/${Date.now()}`,
    noResults: false,
  };
}
