import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE, requireUser } from "@/lib/auth";
import { assertSameOrigin } from "@/lib/csrf";
import { getDb } from "@/lib/db";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser(req.cookies.get(SESSION_COOKIE)?.value);
    const conversations = await getDb().listConversations(user.sub);
    return NextResponse.json({ conversations });
  } catch {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
}

export async function POST(req: NextRequest) {
  if (!assertSameOrigin(req)) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  try {
    const user = await requireUser(req.cookies.get(SESSION_COOKIE)?.value);
    const body = (await req.json().catch(() => ({}))) as { title?: string };
    const title = (body.title ?? "New conversation").slice(0, 120);
    const conversation = await getDb().createConversation(user.sub, title);
    return NextResponse.json({ conversation }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
}
