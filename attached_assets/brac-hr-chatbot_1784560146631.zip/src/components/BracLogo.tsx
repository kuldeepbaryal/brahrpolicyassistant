export function BracLogo({ size = 28 }: { size?: number }) {
  return (
    <div className="flex items-center gap-2.5">
      <div
        className="flex items-center justify-center rounded-xl font-bold text-white shadow-sm"
        style={{
          width: size,
          height: size,
          background: "linear-gradient(135deg, #ee1d80 0%, #b31160 100%)",
          fontSize: size * 0.5,
          fontFamily: "var(--font-display)",
        }}
        aria-hidden
      >
        H
      </div>
      <div className="leading-tight">
        <div className="font-semibold tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
          BRAC HR
        </div>
        <div className="text-[11px] -mt-0.5" style={{ color: "var(--text-faint)" }}>
          Policy Assistant
        </div>
      </div>
    </div>
  );
}
