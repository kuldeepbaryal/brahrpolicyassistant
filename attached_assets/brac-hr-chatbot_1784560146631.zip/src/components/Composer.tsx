"use client";

import { useEffect, useRef, useState } from "react";
import { IconSend } from "./icons";

export function Composer({
  onSend,
  disabled,
  value,
  onValueChange,
}: {
  onSend: (text: string) => void;
  disabled?: boolean;
  value: string;
  onValueChange: (v: string) => void;
}) {
  const taRef = useRef<HTMLTextAreaElement>(null);

  // Auto-grow the textarea up to a cap.
  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(ta.scrollHeight, 200)}px`;
  }, [value]);

  const submit = () => {
    const text = value.trim();
    if (!text || disabled) return;
    onSend(text);
  };

  return (
    <div className="px-4 pb-4 pt-2 sm:px-6">
      <div
        className="mx-auto flex max-w-3xl items-end gap-2 rounded-2xl border p-2 transition-colors focus-within:border-[var(--color-brand-400)]"
        style={{ background: "var(--bg-elevated)", borderColor: "var(--border-strong)", boxShadow: "var(--shadow)" }}
      >
        <textarea
          ref={taRef}
          value={value}
          onChange={(e) => onValueChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
          rows={1}
          placeholder="Ask about BRAC HR policies…"
          disabled={disabled}
          aria-label="Ask an HR question"
          className="max-h-[200px] flex-1 resize-none bg-transparent px-2.5 py-2 text-[0.95rem] leading-relaxed outline-none placeholder:text-[var(--text-faint)] disabled:opacity-60"
          style={{ color: "var(--text)" }}
        />
        <button
          onClick={submit}
          disabled={disabled || !value.trim()}
          aria-label="Send"
          className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white transition-all enabled:hover:scale-105 disabled:opacity-30"
          style={{ background: "linear-gradient(135deg, #ee1d80 0%, #b31160 100%)" }}
        >
          <IconSend />
        </button>
      </div>
      <p className="mx-auto mt-2 max-w-3xl text-center text-[11px]" style={{ color: "var(--text-faint)" }}>
        Answers come from BRAC HR documents and may not cover every case. For official guidance, contact hr@brac.net.
      </p>
    </div>
  );
}
