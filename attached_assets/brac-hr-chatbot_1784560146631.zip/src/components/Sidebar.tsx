"use client";

import { useState } from "react";
import type { Conversation } from "@/lib/types";
import type { PublicUser } from "@/lib/client";
import { BracLogo } from "./BracLogo";
import { ThemeToggle } from "./ThemeToggle";
import { IconClose, IconEdit, IconLogout, IconPlus, IconTrash } from "./icons";

export function Sidebar({
  user,
  conversations,
  activeId,
  open,
  onClose,
  onNew,
  onSelect,
  onRename,
  onDelete,
  onSignOut,
}: {
  user: PublicUser;
  conversations: Conversation[];
  activeId: string | null;
  open: boolean;
  onClose: () => void;
  onNew: () => void;
  onSelect: (id: string) => void;
  onRename: (id: string, title: string) => void;
  onDelete: (id: string) => void;
  onSignOut: () => void;
}) {
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const commitRename = (id: string) => {
    if (draft.trim()) onRename(id, draft.trim());
    setEditing(null);
  };

  return (
    <>
      {open && <div className="fixed inset-0 z-30 bg-black/40 md:hidden" onClick={onClose} aria-hidden />}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r transition-transform md:static md:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
        style={{ background: "var(--bg-sidebar)", borderColor: "var(--border)" }}
      >
        <div className="flex items-center justify-between px-4 py-3.5">
          <BracLogo />
          <button className="grid h-9 w-9 place-items-center rounded-lg hover:bg-[var(--code-bg)] md:hidden" onClick={onClose} aria-label="Close menu">
            <IconClose />
          </button>
        </div>

        <div className="px-3">
          <button
            onClick={onNew}
            className="flex w-full items-center gap-2 rounded-xl border px-3.5 py-2.5 text-sm font-medium transition-colors hover:border-[var(--color-brand-400)] hover:text-[var(--color-brand-600)]"
            style={{ borderColor: "var(--border-strong)", color: "var(--text)" }}
          >
            <IconPlus width={16} height={16} />
            New conversation
          </button>
        </div>

        <nav className="mt-4 flex-1 overflow-y-auto px-2">
          <div className="px-2 pb-1.5 text-[11px] font-medium uppercase tracking-wide" style={{ color: "var(--text-faint)" }}>
            Recent
          </div>
          {conversations.length === 0 && (
            <p className="px-2 py-2 text-xs" style={{ color: "var(--text-faint)" }}>
              No conversations yet.
            </p>
          )}
          <ul className="space-y-0.5">
            {conversations.map((c) => (
              <li key={c.id}>
                <div
                  className={`group flex items-center gap-1 rounded-lg px-2 py-2 text-sm transition-colors ${
                    activeId === c.id ? "" : "hover:bg-[var(--code-bg)]"
                  }`}
                  style={activeId === c.id ? { background: "var(--code-bg)" } : undefined}
                >
                  {editing === c.id ? (
                    <input
                      autoFocus
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      onBlur={() => commitRename(c.id)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") commitRename(c.id);
                        if (e.key === "Escape") setEditing(null);
                      }}
                      className="min-w-0 flex-1 rounded border bg-transparent px-1.5 py-0.5 text-sm outline-none"
                      style={{ borderColor: "var(--color-brand-400)", color: "var(--text)" }}
                    />
                  ) : (
                    <button
                      onClick={() => onSelect(c.id)}
                      className="min-w-0 flex-1 truncate text-left"
                      style={{ color: activeId === c.id ? "var(--text)" : "var(--text-muted)" }}
                      title={c.title}
                    >
                      {c.title}
                    </button>
                  )}
                  {editing !== c.id && (
                    <div className="flex shrink-0 items-center opacity-0 transition-opacity group-hover:opacity-100">
                      <button
                        onClick={() => {
                          setEditing(c.id);
                          setDraft(c.title);
                        }}
                        className="grid h-6 w-6 place-items-center rounded hover:bg-[var(--border-strong)]"
                        style={{ color: "var(--text-faint)" }}
                        aria-label="Rename"
                      >
                        <IconEdit width={13} height={13} />
                      </button>
                      <button
                        onClick={() => onDelete(c.id)}
                        className="grid h-6 w-6 place-items-center rounded hover:bg-[var(--border-strong)]"
                        style={{ color: "var(--text-faint)" }}
                        aria-label="Delete"
                      >
                        <IconTrash width={13} height={13} />
                      </button>
                    </div>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </nav>

        <div className="border-t p-3" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center gap-2.5 rounded-lg px-2 py-1.5">
            <div
              className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-semibold text-white"
              style={{ background: "var(--color-brand-500)" }}
            >
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-medium" style={{ color: "var(--text)" }}>
                {user.name}
              </div>
              <div className="truncate text-xs" style={{ color: "var(--text-faint)" }}>
                {user.email}
              </div>
            </div>
            <ThemeToggle />
            <button
              onClick={onSignOut}
              className="grid h-9 w-9 place-items-center rounded-lg hover:bg-[var(--code-bg)]"
              style={{ color: "var(--text-muted)" }}
              aria-label="Sign out"
              title="Sign out"
            >
              <IconLogout />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
