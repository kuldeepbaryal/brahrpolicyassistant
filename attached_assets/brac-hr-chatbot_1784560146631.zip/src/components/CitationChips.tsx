"use client";

import { useState } from "react";
import type { Citation } from "@/lib/types";
import { IconLink } from "./icons";

export function CitationChips({ citations }: { citations: Citation[] }) {
  const [open, setOpen] = useState<number | null>(null);
  if (!citations.length) return null;

  return (
    <div className="mt-3.5">
      <div className="text-[11px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--text-faint)" }}>
        Sources
      </div>
      <div className="flex flex-wrap gap-1.5">
        {citations.map((c, i) => (
          <button
            key={i}
            onClick={() => setOpen(open === i ? null : i)}
            className="group inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs transition-colors hover:border-[var(--color-brand-400)]"
            style={{
              background: "var(--bg)",
              borderColor: open === i ? "var(--color-brand-500)" : "var(--border-strong)",
            }}
            aria-expanded={open === i}
          >
            <span
              className="grid place-items-center h-4 w-4 rounded-full text-[10px] font-semibold text-white"
              style={{ background: "var(--color-brand-500)" }}
            >
              {i + 1}
            </span>
            <span className="max-w-[220px] truncate" style={{ color: "var(--text-muted)" }}>
              {c.title}
            </span>
          </button>
        ))}
      </div>

      {open !== null && (
        <div
          className="mt-2 rounded-xl border p-3.5 text-sm animate-fade-in"
          style={{ background: "var(--bg)", borderColor: "var(--border-strong)" }}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="font-medium" style={{ color: "var(--text)" }}>
              {citations[open].title}
            </div>
            {citations[open].uri && (
              <a
                href={citations[open].uri}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs whitespace-nowrap hover:underline"
                style={{ color: "var(--color-brand-600)" }}
              >
                <IconLink width={13} height={13} /> Open
              </a>
            )}
          </div>
          {citations[open].snippet && (
            <p className="mt-1.5 leading-relaxed" style={{ color: "var(--text-muted)" }}>
              {citations[open].snippet}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
