"use client";

import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { ChatMessage } from "@/lib/types";
import { CitationChips } from "./CitationChips";
import { IconThumbDown, IconThumbUp } from "./icons";

export function TypingDots() {
  return (
    <div className="flex items-center gap-1 py-1" aria-label="Assistant is typing">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="typing-dot h-1.5 w-1.5 rounded-full"
          style={{ background: "var(--color-brand-500)", animationDelay: `${i * 0.15}s` }}
        />
      ))}
    </div>
  );
}

interface MessageProps {
  message: ChatMessage;
  streaming?: boolean;
  onFeedback?: (rating: "up" | "down") => void;
  onRelatedClick?: (q: string) => void;
}

export function Message({ message, streaming, onFeedback, onRelatedClick }: MessageProps) {
  const isUser = message.role === "user";

  if (isUser) {
    return (
      <div className="flex justify-end animate-msg-in">
        <div
          className="max-w-[85%] rounded-2xl rounded-br-md px-4 py-2.5 text-[0.95rem] leading-relaxed"
          style={{ background: "var(--bubble-user)", color: "var(--bubble-user-text)" }}
        >
          {message.content}
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-3 animate-msg-in">
      <div
        className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg text-sm font-bold text-white"
        style={{ background: "linear-gradient(135deg, #ee1d80 0%, #b31160 100%)", fontFamily: "var(--font-display)" }}
        aria-hidden
      >
        H
      </div>
      <div className="min-w-0 flex-1">
        <div
          className="rounded-2xl rounded-tl-md border px-4 py-3"
          style={{ background: "var(--bubble-assistant)", borderColor: "var(--border)", boxShadow: "var(--shadow)" }}
        >
          {message.content ? (
            <div className="prose-answer" style={{ color: "var(--text)" }}>
              <ReactMarkdown remarkPlugins={[remarkGfm]}>{message.content}</ReactMarkdown>
            </div>
          ) : (
            <TypingDots />
          )}

          {!streaming && message.citations && <CitationChips citations={message.citations} />}
        </div>

        {!streaming && message.content && (
          <div className="mt-1.5 flex items-center gap-1 pl-1">
            <FeedbackButton
              active={message.feedback === "up"}
              onClick={() => onFeedback?.("up")}
              label="Helpful"
              icon={<IconThumbUp width={15} height={15} />}
            />
            <FeedbackButton
              active={message.feedback === "down"}
              onClick={() => onFeedback?.("down")}
              label="Not helpful"
              icon={<IconThumbDown width={15} height={15} />}
            />
          </div>
        )}

        {!streaming && message.relatedQuestions && message.relatedQuestions.length > 0 && (
          <div className="mt-2.5 flex flex-wrap gap-1.5 pl-1">
            {message.relatedQuestions.slice(0, 3).map((q, i) => (
              <button
                key={i}
                onClick={() => onRelatedClick?.(q)}
                className="rounded-full border px-3 py-1 text-xs transition-colors hover:border-[var(--color-brand-400)] hover:text-[var(--color-brand-600)]"
                style={{ borderColor: "var(--border-strong)", color: "var(--text-muted)" }}
              >
                {q}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function FeedbackButton({
  active,
  onClick,
  label,
  icon,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  icon: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      aria-label={label}
      title={label}
      className="grid h-7 w-7 place-items-center rounded-md transition-colors hover:bg-[var(--code-bg)]"
      style={{ color: active ? "var(--color-brand-500)" : "var(--text-faint)" }}
    >
      {icon}
    </button>
  );
}
