"use client";

import { useEffect, useRef, useState } from "react";
import { api, type PublicUser } from "@/lib/client";
import { BracLogo } from "./BracLogo";
import { ThemeToggle } from "./ThemeToggle";

declare global {
  interface Window {
    google?: {
      accounts: {
        id: {
          initialize: (o: Record<string, unknown>) => void;
          renderButton: (el: HTMLElement, o: Record<string, unknown>) => void;
        };
      };
    };
  }
}

export function LoginScreen({
  clientId,
  hostedDomain,
  mockMode,
  onSignedIn,
}: {
  clientId: string;
  hostedDomain: string;
  mockMode: boolean;
  onSignedIn: (user: PublicUser) => void;
}) {
  const btnRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const handleCredential = async (credential: string) => {
    setError(null);
    setBusy(true);
    try {
      onSignedIn(await api.signIn(credential));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Sign-in failed.");
      setBusy(false);
    }
  };

  useEffect(() => {
    if (mockMode) return;
    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.onload = () => {
      if (!window.google || !btnRef.current) return;
      window.google.accounts.id.initialize({
        client_id: clientId,
        callback: (resp: { credential: string }) => handleCredential(resp.credential),
        hd: hostedDomain, // client-side hint only; server enforces the real check
        auto_select: false,
        cancel_on_tap_outside: true,
      });
      window.google.accounts.id.renderButton(btnRef.current, {
        theme: "filled_black",
        size: "large",
        shape: "pill",
        text: "signin_with",
        width: 280,
      });
    };
    document.body.appendChild(script);
    return () => {
      script.remove();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clientId, hostedDomain, mockMode]);

  return (
    <div className="relative flex min-h-dvh items-center justify-center overflow-hidden px-6" style={{ background: "var(--bg)" }}>
      {/* Ambient brand glow */}
      <div
        className="pointer-events-none absolute -top-40 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full opacity-25 blur-3xl"
        style={{ background: "radial-gradient(circle, #ee1d80, transparent 70%)" }}
        aria-hidden
      />
      <div className="absolute right-5 top-5">
        <ThemeToggle />
      </div>

      <div className="relative w-full max-w-md animate-fade-in">
        <div
          className="rounded-3xl border p-8 text-center sm:p-10"
          style={{ background: "var(--bg-elevated)", borderColor: "var(--border)", boxShadow: "var(--shadow)" }}
        >
          <div className="flex justify-center">
            <BracLogo size={44} />
          </div>

          <h1 className="mt-7 text-2xl font-semibold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--text)" }}>
            Your HR questions, answered
          </h1>
          <p className="mx-auto mt-2.5 max-w-sm text-sm leading-relaxed" style={{ color: "var(--text-muted)" }}>
            Ask about leave, benefits, or any BRAC HR policy. Every answer is grounded in official HR documents and cites its sources.
          </p>

          <div className="mt-8 flex flex-col items-center gap-3">
            {mockMode ? (
              <button
                onClick={() => handleCredential("mock")}
                disabled={busy}
                className="rounded-full px-6 py-3 text-sm font-medium text-white transition-transform hover:scale-[1.02] disabled:opacity-60"
                style={{ background: "linear-gradient(135deg, #ee1d80 0%, #b31160 100%)" }}
              >
                {busy ? "Signing in…" : "Continue (mock dev user)"}
              </button>
            ) : (
              <div ref={btnRef} className="min-h-[44px]" />
            )}

            {error && (
              <div
                className="mt-1 rounded-lg px-3 py-2 text-sm"
                style={{ background: "var(--color-brand-50)", color: "var(--color-brand-700)" }}
                role="alert"
              >
                {error}
              </div>
            )}
          </div>

          <div className="mt-8 border-t pt-5 text-xs leading-relaxed" style={{ borderColor: "var(--border)", color: "var(--text-faint)" }}>
            Access is restricted to <span className="font-medium" style={{ color: "var(--text-muted)" }}>@{hostedDomain}</span> Google Workspace accounts.
            {mockMode && <div className="mt-1 font-medium text-[var(--color-brand-600)]">⚠ Running in local mock mode — no real data.</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
