"use client";

const STARTERS = [
  "How many days of annual leave do I get?",
  "What is the maternity leave policy?",
  "How long is the probation period?",
  "How do I claim medical expenses?",
];

export function EmptyState({ onPick }: { onPick: (q: string) => void }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center px-6 py-10 text-center animate-fade-in">
      <div
        className="grid h-14 w-14 place-items-center rounded-2xl text-2xl font-bold text-white shadow-lg"
        style={{ background: "linear-gradient(135deg, #ee1d80 0%, #b31160 100%)", fontFamily: "var(--font-display)" }}
        aria-hidden
      >
        H
      </div>
      <h2 className="mt-5 text-2xl font-semibold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--text)" }}>
        How can I help with HR today?
      </h2>
      <p className="mt-2 max-w-md text-sm leading-relaxed" style={{ color: "var(--text-muted)" }}>
        Ask about leave, benefits, payroll, or any BRAC HR policy. I'll answer from official HR documents and show you the sources.
      </p>

      <div className="mt-8 grid w-full max-w-xl gap-2.5 sm:grid-cols-2">
        {STARTERS.map((q) => (
          <button
            key={q}
            onClick={() => onPick(q)}
            className="group rounded-xl border px-4 py-3 text-left text-sm transition-all hover:-translate-y-0.5 hover:border-[var(--color-brand-400)]"
            style={{ background: "var(--bg-elevated)", borderColor: "var(--border)", color: "var(--text-muted)", boxShadow: "var(--shadow)" }}
          >
            <span className="transition-colors group-hover:text-[var(--color-brand-600)]">{q}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
