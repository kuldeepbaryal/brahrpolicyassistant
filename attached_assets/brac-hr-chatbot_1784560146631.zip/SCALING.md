# Scaling BRAC HR Assistant

The service is **stateless** — all shared state lives in Firestore — so scaling
is mostly a matter of Cloud Run knobs, Discovery Engine quota, and cache TTLs.
Baseline deploy: `min-instances=1`, `max-instances=20`, `concurrency=80`.

## At ~100 daily users (pilot / launch)

Baseline is comfortable. Nothing to change.

- `min-instances=1` keeps cold starts away for the whole org at low cost.
- `max-instances=20`, `concurrency=80` → headroom for ~1,600 in-flight requests.
- Default Discovery Engine per-minute query quota is fine.
- Answer cache TTL `3600s` (1h) already absorbs repeated common questions.

**Watch:** p95 latency and error rate in Cloud Run metrics; feedback 👎 rate.

## At ~1,000 daily users

- **Cloud Run:** `max-instances=40`. Keep `concurrency=80` (the work is I/O-bound on the Answer API, so high concurrency per instance is efficient). Consider `min-instances=2` if morning traffic spikes cause brief cold-start latency.
- **Discovery Engine quota:** you may approach the per-minute `answer` quota. Request an increase: **IAM & Admin → Quotas → filter "Discovery Engine API" → `answer` / query requests per minute → Edit Quotas.** The app already backs off + retries on 429 and shows a calm "high traffic" message, so users degrade gracefully rather than erroring.
- **Cache:** raise `ANSWER_CACHE_TTL_SECONDS` to `7200` (2h) for common HR questions if answers are stable between policy updates. Lower it right after a policy document changes so stale answers don't linger.
- **Firestore:** no action — well within autoscaling limits. Ensure the `answerCache` TTL policy is enabled so expired docs are reclaimed.
- **Rate limit:** `RATE_LIMIT_PER_HOUR=30` is generous for genuine HR use; keep it as an abuse/cost backstop.

## At ~10,000 daily users

- **Cloud Run:** `max-instances=80–100`, `min-instances=3–5`. Set a **billing budget alert** and, if spend must be hard-bounded, keep `max-instances` conservative and let the "high traffic" message shed load rather than allowing unbounded scale.
- **Discovery Engine quota:** proactively request a substantial per-minute quota increase *before* an org-wide announcement — quota approval is not instant. Model peak QPS as `daily_users × avg_questions × peak_fraction / peak_seconds`.
- **Cache:** this is your biggest cost lever. At this scale a large share of questions are duplicates ("leave policy?" asked hundreds of times). Keep TTL at `3600–7200s`; consider normalizing more aggressively (e.g. strip filler words) in `src/lib/cache.ts` to raise the hit rate. Every cache hit is a Discovery Engine call you don't pay for.
- **Rate limit:** revisit per-user limits and add a **global** per-minute ceiling if a single event (e.g. open-enrolment) could stampede the Answer API beyond quota.
- **Observability:** add log-based metrics + alerting on: 429 rate (quota pressure), p95 latency, error-class `api_error`, and cache-hit ratio. The structured logs in `src/lib/logger.ts` already carry these fields (`errorClass`, `latencyMs`, `cached`, `noResults`).
- **Firestore:** consider periodic cleanup of very old conversations if storage grows; conversations are per-user and small, so this is usually unnecessary.

## Cost levers, ranked

1. **Answer cache hit rate** — directly cuts paid Discovery Engine calls.
2. **`max-instances` cap** — bounds worst-case compute spend.
3. **`min-instances`** — trades a small always-on cost for zero cold starts.
4. **Rate limit** — backstop against runaway per-user or abusive usage.

## What NOT to do

- Don't add in-memory caching/session state in the app — it breaks correctness across instances. Everything shared must go through Firestore (`src/lib/db.ts`).
- Don't remove `min-instances` to save money at higher scale — cold starts on a busy org hurt more than they save.
