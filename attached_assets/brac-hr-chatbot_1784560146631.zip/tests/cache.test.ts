import { describe, expect, it } from "vitest";
import { normalizeQuestion, questionHash } from "@/lib/cache";

describe("question normalization + hashing", () => {
  it("normalizes case, whitespace and trailing punctuation", () => {
    expect(normalizeQuestion("  How  much   LEAVE do I get?? ")).toBe("how much leave do i get");
  });

  it("hashes equal normalized questions identically", () => {
    expect(questionHash("What is the leave policy?")).toBe(questionHash("what is the LEAVE policy"));
  });

  it("hashes different questions differently", () => {
    expect(questionHash("maternity leave")).not.toBe(questionHash("paternity leave"));
  });
});
