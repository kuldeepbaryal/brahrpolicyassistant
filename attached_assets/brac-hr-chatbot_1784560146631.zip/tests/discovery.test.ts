import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";

beforeAll(() => {
  process.env.GCP_PROJECT_ID = "test-project";
  process.env.GCP_LOCATION = "global";
  process.env.ENGINE_ID = "test-engine";
  process.env.GOOGLE_OAUTH_CLIENT_ID = "c";
  process.env.SESSION_SECRET = "s".repeat(32);
  // Not mock mode: exercise the real REST path with fetch mocked.
  process.env.MOCK_MODE = "false";
});

// Stub the access-token fetch so no real ADC is needed.
vi.mock("google-auth-library", () => ({
  GoogleAuth: class {
    async getAccessToken() {
      return "fake-token";
    }
  },
  OAuth2Client: class {},
}));

const { answerQuery, QuotaError } = await import("@/lib/discovery");

afterEach(() => {
  vi.restoreAllMocks();
});

function mockFetchOnce(status: number, body: unknown) {
  vi.stubGlobal(
    "fetch",
    vi.fn(async () => ({
      ok: status >= 200 && status < 300,
      status,
      json: async () => body,
      text: async () => JSON.stringify(body),
    }))
  );
}

describe("answerQuery (mocked Answer API)", () => {
  it("parses answer text, citations and related questions", async () => {
    mockFetchOnce(200, {
      answer: {
        answerText: "You get 20 days of annual leave.",
        state: "SUCCEEDED",
        references: [
          {
            unstructuredDocumentInfo: {
              title: "HR Policy Manual",
              uri: "https://drive.google.com/doc",
              chunkContents: [{ content: "Annual leave is 20 days." }],
            },
          },
        ],
        relatedQuestions: ["How do I apply for leave?"],
      },
      session: { name: "projects/x/sessions/abc" },
    });

    const result = await answerQuery("How much leave?", { userPseudoId: "u", sessionName: null });
    expect(result.answerText).toContain("20 days");
    expect(result.citations).toHaveLength(1);
    expect(result.citations[0].title).toBe("HR Policy Manual");
    expect(result.citations[0].uri).toBe("https://drive.google.com/doc");
    expect(result.relatedQuestions).toContain("How do I apply for leave?");
    expect(result.sessionName).toBe("projects/x/sessions/abc");
    expect(result.noResults).toBe(false);
  });

  it("flags noResults when the engine skips the answer", async () => {
    mockFetchOnce(200, {
      answer: { answerText: "", answerSkippedReasons: ["NON_ANSWER_SEEKING_QUERY"] },
    });
    const result = await answerQuery("hello", { userPseudoId: "u", sessionName: null });
    expect(result.noResults).toBe(true);
  });

  it("throws QuotaError on HTTP 429", async () => {
    // All retries return 429 → surfaces QuotaError.
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({ ok: false, status: 429, json: async () => ({}), text: async () => "" }))
    );
    await expect(answerQuery("q", { userPseudoId: "u", sessionName: null })).rejects.toBeInstanceOf(QuotaError);
  }, 10000);

  it("deduplicates repeated citation sources", async () => {
    mockFetchOnce(200, {
      answer: {
        answerText: "Answer.",
        references: [
          { unstructuredDocumentInfo: { title: "Doc A", uri: "u1", chunkContents: [{ content: "x" }] } },
          { unstructuredDocumentInfo: { title: "Doc A", uri: "u1", chunkContents: [{ content: "y" }] } },
        ],
      },
    });
    const result = await answerQuery("q", { userPseudoId: "u", sessionName: null });
    expect(result.citations).toHaveLength(1);
  });
});
