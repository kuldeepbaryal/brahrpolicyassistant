import { beforeAll, describe, expect, it } from "vitest";

beforeAll(() => {
  process.env.GOOGLE_OAUTH_CLIENT_ID = "c";
  process.env.SESSION_SECRET = "s".repeat(32);
  process.env.RATE_LIMIT_PER_HOUR = "3";
});

const { MemoryDb } = await import("@/lib/db");
const { checkRateLimit, windowKeyFor } = await import("@/lib/ratelimit");

describe("rate limiting", () => {
  it("allows up to the limit then blocks", async () => {
    const db = new MemoryDb();
    const now = new Date("2026-07-20T10:00:00Z");
    const results = [];
    for (let i = 0; i < 4; i++) {
      results.push(await checkRateLimit(db, "user-a", now));
    }
    expect(results.map((r) => r.allowed)).toEqual([true, true, true, false]);
    expect(results[0].remaining).toBe(2);
    expect(results[3].remaining).toBe(0);
  });

  it("isolates counters per user", async () => {
    const db = new MemoryDb();
    const now = new Date("2026-07-20T10:00:00Z");
    await checkRateLimit(db, "user-a", now);
    await checkRateLimit(db, "user-a", now);
    const b = await checkRateLimit(db, "user-b", now);
    expect(b.allowed).toBe(true);
    expect(b.remaining).toBe(2);
  });

  it("resets across hour windows", async () => {
    const db = new MemoryDb();
    const h10 = new Date("2026-07-20T10:59:00Z");
    const h11 = new Date("2026-07-20T11:00:00Z");
    await checkRateLimit(db, "user-a", h10);
    await checkRateLimit(db, "user-a", h10);
    await checkRateLimit(db, "user-a", h10); // exhausts hour 10
    const next = await checkRateLimit(db, "user-a", h11);
    expect(next.allowed).toBe(true);
  });

  it("builds distinct UTC hour window keys", () => {
    expect(windowKeyFor("u", new Date("2026-07-20T10:30:00Z"))).toBe("u_2026072010");
    expect(windowKeyFor("u", new Date("2026-07-20T11:30:00Z"))).toBe("u_2026072011");
  });
});
