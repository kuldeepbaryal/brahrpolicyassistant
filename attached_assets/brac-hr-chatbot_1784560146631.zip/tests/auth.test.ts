import { beforeAll, describe, expect, it } from "vitest";

beforeAll(() => {
  process.env.GOOGLE_OAUTH_CLIENT_ID = "test-client.apps.googleusercontent.com";
  process.env.ALLOWED_HOSTED_DOMAIN = "brac.net";
  process.env.SESSION_SECRET = "test-secret-value-for-vitest-only-123456";
});

// Import after env is set so config picks it up.
const { verifyGoogleIdToken, AuthError, createSessionJwt, verifySessionJwt } = await import("@/lib/auth");

/** Build a fake verifyIdToken client returning a fixed payload. */
function fakeClient(payload: Record<string, unknown> | null) {
  return {
    async verifyIdToken() {
      if (payload === null) throw new Error("bad signature");
      return { getPayload: () => payload };
    },
  } as any;
}

const validPayload = {
  sub: "123",
  email: "staff@brac.net",
  email_verified: true,
  name: "BRAC Staff",
  iss: "https://accounts.google.com",
  hd: "brac.net",
  aud: "test-client.apps.googleusercontent.com",
};

describe("verifyGoogleIdToken", () => {
  it("accepts a valid brac.net token", async () => {
    const user = await verifyGoogleIdToken("tok", { client: fakeClient(validPayload) });
    expect(user.email).toBe("staff@brac.net");
    expect(user.sub).toBe("123");
  });

  it("rejects a gmail.com user (no hd claim) with wrong_domain", async () => {
    const gmail = { ...validPayload, email: "someone@gmail.com", hd: undefined };
    await expect(verifyGoogleIdToken("tok", { client: fakeClient(gmail) })).rejects.toMatchObject({
      code: "wrong_domain",
    });
  });

  it("rejects a different Workspace domain with wrong_domain", async () => {
    const other = { ...validPayload, email: "x@other.org", hd: "other.org" };
    await expect(verifyGoogleIdToken("tok", { client: fakeClient(other) })).rejects.toMatchObject({
      code: "wrong_domain",
    });
  });

  it("rejects a token whose signature fails", async () => {
    await expect(verifyGoogleIdToken("tok", { client: fakeClient(null) })).rejects.toBeInstanceOf(AuthError);
  });

  it("rejects an unexpected issuer", async () => {
    const badIss = { ...validPayload, iss: "https://evil.example.com" };
    await expect(verifyGoogleIdToken("tok", { client: fakeClient(badIss) })).rejects.toMatchObject({
      code: "invalid_token",
    });
  });

  it("rejects an unverified email", async () => {
    const unverified = { ...validPayload, email_verified: false };
    await expect(verifyGoogleIdToken("tok", { client: fakeClient(unverified) })).rejects.toBeInstanceOf(AuthError);
  });
});

describe("session JWT round-trip", () => {
  it("signs and verifies a session", async () => {
    const jwt = await createSessionJwt({ sub: "u1", email: "a@brac.net", name: "A" });
    const user = await verifySessionJwt(jwt);
    expect(user.email).toBe("a@brac.net");
  });

  it("rejects a tampered session token", async () => {
    const jwt = await createSessionJwt({ sub: "u1", email: "a@brac.net", name: "A" });
    await expect(verifySessionJwt(jwt + "x")).rejects.toMatchObject({ code: "no_session" });
  });
});
